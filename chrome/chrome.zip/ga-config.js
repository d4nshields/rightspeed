var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-48191515-2']);
_gaq.push(['_setDomainName', 'youtube.com']); 
_gaq.push(['_trackPageview']);
_gaq.push(['_trackEvent', 'pageView']);
